
const userRoles = {
    'a@gmail.com': 'admin',
    'u@gmail.com': 'user',
    'guest': 'guest'
};


function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
}


function hideLoginForm() {
    document.getElementById('loginForm').style.display = 'none';
}


function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const role = userRoles[email];

    if (role) {
        alert(`Chào mừng bạn, bạn có quyền ${role}`);
        updateMenu(role);
        hideLoginForm();
    } else {
        alert('Email không hợp lệ!');
    }
}


function updateMenu(role) {
    const xemMenu = document.getElementById('xemMenu');
    const datLichMenu = document.getElementById('datLichMenu');
    const nhap = document.getElementById('nhap');

    xemMenu.style.display = 'none';
    datLichMenu.style.display = 'none';
    nhap.style.display = 'none';
    if (role === 'admin') {
        xemMenu.style.display = 'inline';
        nhap.style.display = 'inline';
    } else if (role === 'user') {
        datLichMenu.style.display = 'inline';
    }

  
}

document.getElementById("specialty").addEventListener("change", function() {
    const specialty = this.value;
    const doctorSelect = document.getElementById("doctor");
    

    doctorSelect.innerHTML = '<option value="">Chọn framework</option>';
    
    if (specialty === "back") {
        const doctors = [
            "vuejs",
            "reactjs"
        ];
        doctors.forEach(function(doctor) {
            const option = document.createElement("option");
            option.value = doctor;
            option.textContent = doctor;
            doctorSelect.appendChild(option);
        });
    } else if (specialty === "front") {
        const doctors = [
            "dotnet core",
            "spring boots"
        ];
        doctors.forEach(function(doctor) {
            const option = document.createElement("option");
            option.value = doctor;
            option.textContent = doctor;
            doctorSelect.appendChild(option);
        });
    }
});


function handleSubmit(event) {
    event.preventDefault();

  
    const name = document.getElementById("name").value;
    const phone = document.getElementById("phone").value;
    const specialty = document.getElementById("specialty").value;
    const doctor = document.getElementById("doctor").value;


    if (!name || !phone || !specialty || !doctor) {
        alert("Vui lòng điền đầy đủ thông tin.");
        return;
    }

   
    const url = `thanhcong.html?name=${encodeURIComponent(name)}&specialty=${encodeURIComponent(specialty)}&doctor=${encodeURIComponent(doctor)}`;

 
    window.location.href = url;
}
function openNhap(){
    window.location.href='form-nhap.html';
  }